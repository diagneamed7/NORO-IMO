# Portage EXACT du design NORO Immobilier vers React (pas une refonte)

## Regle absolue

Le fichier `index-reference-design.html` (a la racine de ce dossier) est le
design DEFINITIF, deja valide par le client. Ta seule mission est de porter
ce HTML/CSS/JS existant en composants React, a l'identique, pixel pres.

INTERDIT :
- Changer une seule couleur, taille de police, marge, ombre ou arrondi
- Remplacer une police par une autre
- Utiliser Tailwind, un design system, ou des styles "par defaut" d'une
  librairie de composants
- "Ameliorer" ou "simplifier" la mise en page
- Regenerer le CSS depuis zero au lieu de reprendre l'existant

Si un doute existe sur un style, la reference absolue est
`reference-styles.css` (le <style> exact extrait du HTML original) et
`reference-body.html` (le <body> exact extrait du HTML original). Copie ces
styles TELS QUELS dans le projet React, ne les reecris pas.

## Methode de portage attendue

1. Prendre `reference-styles.css` et le placer quasi tel quel dans
   `src/styles/global.css` (import global dans `main.jsx`). Tu peux
   seulement reorganiser en plusieurs fichiers CSS si besoin (un par
   composant), mais chaque regle CSS doit rester exactement la meme valeur
   qu'aujourd'hui.
2. Prendre `reference-body.html` et decouper sa structure HTML en composants
   React logiques (TopBar, Header, Hero, SearchBar, PropertyGrid,
   PropertyCard, PropertyModal, ContactModal, Services, Simulateur,
   Testimonials, CtaBand, Footer), en gardant EXACTEMENT les memes classes
   CSS, la meme structure de balises, le meme texte.
3. Porter le `<script>` JS existant (present a la fin du fichier original)
   en logique React equivalente : les memes fonctions (filtres, ouverture
   modale, simulateur, formulaire WhatsApp) mais en state React
   (useState/useEffect) au lieu de manipulation directe du DOM. Le
   comportement doit etre identique a l'original, pas seulement l'apparence.
4. Le hook de donnees `useProperties()` doit fetch `/data/properties.json`
   (genere par `scripts/build-data.js`, deja en place, ne pas toucher).
5. Ne pas toucher `admin/`, `content/`, `scripts/build-data.js`.
6. A la fin, compare visuellement (capture d'ecran ou description) le rendu
   React avec `index-reference-design.html` ouvert dans un navigateur : ils
   doivent etre indiscernables.

## Fichiers fournis dans ce dossier

- `index-reference-design.html` : le fichier complet original (source de
  verite absolue)
- `reference-styles.css` : uniquement le CSS extrait, pret a copier
- `reference-body.html` : uniquement le HTML du body extrait, pret a
  decouper en composants

## Stack

Vite + React, JavaScript (pas besoin de TypeScript). CSS classique (pas de
Tailwind, pas de styled-components) pour rester au plus proche de l'existant.
